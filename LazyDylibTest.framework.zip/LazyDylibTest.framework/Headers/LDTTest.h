//
//  LDTTest.h
//  LazyDylibTest
//
//  Created by ello on 2022/3/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LDTTest : NSObject

@property (nonatomic, strong, readonly) NSString *text;

-(void)log;


@end

NS_ASSUME_NONNULL_END
